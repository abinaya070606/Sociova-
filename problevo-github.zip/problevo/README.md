# Problevo

**AI-Powered Innovation and Problem Statement Discovery Platform**
Team **Sociova** · Tamil Nadu, India · Category: Technology and Innovation

> **Status: early prototype.** This repository holds a front-end working model that demonstrates the idea. The listings are sample data, and the full platform described below is a proposal, not a finished product.

## The problem
Students preparing for hackathons and ideathons have to search many websites, portals and papers to find a good problem statement. Even after finding one, it is hard to know whether similar projects already exist. This leads to wasted time and duplicated effort.

## The idea
Problevo is a proposed website that brings problem statements from different innovation platforms into one place, so users can discover real-world problems, explore existing work and collaborate.

## Planned features
- Centralized problem discovery with links to the original sources
- Smart search by topic, domain or keyword
- Existing solution discovery (GitHub repositories, research papers)
- AI-assisted similarity analysis (guidance only; it cannot guarantee a problem is unsolved)
- Suggestions on possible gaps in existing solutions
- Community discussion and collaboration
- Problem submission for individuals and organizations
- Save and bookmark

## What the prototype in this repo does today
- Search and domain filter over a small **sample** dataset
- Problem detail page with live GitHub, Crossref and web search links built from the problem title
- Basic keyword-overlap "possibly related problems" (not a trained AI model)
- Rule-based questions to help spot gaps
- Comments, problem submission and bookmarks, saved in the visitor's own browser (`localStorage`), not shared between users

## What is not built yet
- Real data from My Bharat, Smart India Hackathon or other portals
- Backend, database and user accounts
- AI models for similarity, categorization, summarization and recommendations
- Moderation and reporting

## Planned tech stack
React.js + Tailwind CSS (frontend) · Python FastAPI (backend) · PostgreSQL (database) · AI for similarity, categorization, summarization and recommendations. External sources such as GitHub and research metadata services will be explored subject to API availability and permissions.

## Run it locally
No build step is needed. Download the repo and open `index.html` in a browser.

## Live demo
Add your GitHub Pages link here after enabling Pages: `https://<your-username>.github.io/problevo/`

## Team Sociova
| Name | Role |
|------|------|
| [Member 1] | [Role] |
| [Member 2] | [Role] |
| [Member 3] | [Role] |

## Sustainable Development Goals
SDG 4 (Quality Education) · SDG 9 (Industry, Innovation and Infrastructure) · SDG 17 (Partnerships for the Goals)
